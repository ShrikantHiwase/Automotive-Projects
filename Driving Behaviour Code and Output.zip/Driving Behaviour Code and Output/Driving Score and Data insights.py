# -*- coding: utf-8 -*-
"""
Created on Mon Jul  4 17:04:01 2022

@author: Shrikant
"""

import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns


def get_sec(time_str):
    
    h, m, s = time_str.strftime('%H'),time_str.strftime('%M'),time_str.strftime('%S'),

    return int(h) * 3600 + int(m) * 60 + int(s)

#importing dataset
dataset = pd.read_excel('triproute.xls')
df = pd.DataFrame(dataset)

#replace na with 0
df.fillna(0, inplace=True)
#normalizing with time
time = df["total_time"].apply(get_sec)
#print(time)


#crash
Crash_Hr = ((df['Crash']/time))*3600


#Alarms per hour
Alarms_Hr = ((df['Alarms']/time))*3600


ls=[]
#Max speed ratio Speed limit consider 80kmph
for index, row in df.iterrows():
    Max_spd=row['max_speed']
    if Max_spd > 80:
        Exs_spd_rto  = ((Max_spd - 80)*100/80)
        ls.append(Exs_spd_rto)
    else:
        Exs_spd_rto= 0
        ls.append(Exs_spd_rto)    
df["Ovr_Sp_Rto"]=ls


#Overspeed events per hour
Ovr_Speed_Hr = ((df['speedoverlimit']/time))*3600


#Deacceleration per hour
Dcc_Hr = ((df['SuddenDcc']/time))*3600


#Acceleration per hour
Acc_Hr = ((df['SuddenAcc']/time))*3600

#Fuel efficiency
df['Fueleff']=(df['distance_travelled']/(df['fuel_consumption']*1000))
print(df["Fueleff"])
df.replace([np.inf, -np.inf], 0, inplace=True)
mean_FE = df['Fueleff'].mean()
print(mean_FE)
df["Deviation from mean FE"]=(df['Fueleff']-mean_FE)

#weigths (Configurable)
x=.4 #Crash  Maximum toll on score for crash
y=.05 #Alarms  
z=.1 #SPeed over limit
p=.1 #over speed count
q=.05 #Decceleration
r=.05 #Acceleration
s=1 #Bonus for FE
#Score
score=100 - x*Crash_Hr - y*Alarms_Hr - z*df['Ovr_Sp_Rto'] - p*Ovr_Speed_Hr - q*Dcc_Hr - r*Acc_Hr -s*(mean_FE-df['Fueleff'])

df['Score']=score
print(df)

df.to_excel("Score output.xlsx")